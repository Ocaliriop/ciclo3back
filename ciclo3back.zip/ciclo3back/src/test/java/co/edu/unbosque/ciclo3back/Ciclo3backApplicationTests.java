package co.edu.unbosque.ciclo3back;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ciclo3backApplicationTests {

	@Test
	void contextLoads() {
	}

}
